module com.viewnext.ejemplo8 {
	requires java.sql;
}