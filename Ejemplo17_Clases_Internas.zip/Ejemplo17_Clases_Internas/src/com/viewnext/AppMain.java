package com.viewnext;

import java.lang.reflect.Method;

public class AppMain {

	public static void main(String[] args) throws Exception {
		
		EjemploUI ui = new EjemploUI();
		
		// No tengo acceso a un metodo privado de otra clase
		// ui.addListener();
		
		// En Java 11 se introduce esta mejora
		Method metodo = ui.getClass().getNestHost().getDeclaredMethod("addListener");
		metodo.setAccessible(true);
		metodo.invoke(ui);
		
		ui.launchFrame();

	}

}
