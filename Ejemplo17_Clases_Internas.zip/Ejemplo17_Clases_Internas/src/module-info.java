module com.viewnext.ejemplo17 {
	requires java.desktop;
}