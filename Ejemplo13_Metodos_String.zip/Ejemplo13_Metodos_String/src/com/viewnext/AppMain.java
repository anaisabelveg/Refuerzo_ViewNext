package com.viewnext;

import java.util.List;
import java.util.stream.Collectors;

public class AppMain {

	public static void main(String[] args) {
		
		// isBlank
		String prueba = null;
		System.out.println("Hola".isBlank());
		System.out.println("  ".isBlank());
		System.out.println("".isBlank());
		System.out.println("\t".isBlank());
		System.out.println("\n".isBlank());
		//System.out.println(prueba.isBlank());
		
		// repeat
		System.out.println("*".repeat(20));
		System.out.println("-".repeat(50));
		System.out.println("ja".repeat(5));
		
		// strip
		String nombre = "    Juan    ";
		System.out.println("Hola," + nombre + ".");
		
		// Quitar los espacios izquierda y derecha
		System.out.println("Hola," + nombre.strip() + ".");
		
		// Quitar los espacios a la izquierda
		System.out.println("Hola," + nombre.stripLeading() + ".");
		
		// Quitar los espacios de la derecha
		System.out.println("Hola," + nombre.stripTrailing() + ".");
		
		// lines
		String texto = "Hola\nque tal?\nmañana es miercoles";
		System.out.println(texto);
		List<String> lista = texto.lines().collect(Collectors.toList());
		System.out.println(lista);
		
		lista.stream()
			.map(dato -> dato.toUpperCase())
			.forEach(System.out::println);
	}

}
