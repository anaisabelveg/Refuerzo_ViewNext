module com.viewnext.ejemplo9 {
	requires java.net.http;
}