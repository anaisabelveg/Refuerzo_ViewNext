module com.viewnext.ejercicio1 {
	
	requires java.net.http;
	requires org.json;
	
	
}