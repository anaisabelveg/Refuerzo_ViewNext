module com.viewnext.ejemplo1 {
	
	// exports paquete
	exports com.viewnext.models;
}