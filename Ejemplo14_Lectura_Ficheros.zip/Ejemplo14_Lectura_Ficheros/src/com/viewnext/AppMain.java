package com.viewnext;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

public class AppMain {

	public static void main(String[] args) {
		
		String fichero = "datos.txt";
		Path path = Paths.get(fichero);
		
		
		try {
			// Leer todo el contenido de una sola vez y lo retorna como un String
			String contenido = Files.readString(path);
			System.out.println(contenido);
			System.out.println("-".repeat(30));
			
			// Leer todo el contenido de una sola vez y lo retorna como una lista
			List<String> lista = Files.readAllLines(path);
			System.out.println(lista);
			lista.stream().forEach(System.out::println);
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		

	}

}
