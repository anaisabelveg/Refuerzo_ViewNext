package com.viewnext;

import java.util.ArrayList;
import java.util.Arrays;

public class AppMain {
	
	// No podemos utilizar inferencia de tipos en variables globales
	// var numero = 7;

	public static void main(String[] args) {
		
		// La inferencia de tipos solo funciona en variables locales
		var prueba = 200;
		
		// la variable prueba solo admite numeros
		//prueba = "Hola";
		//prueba = true;
		
		// No se puede aplicar a variables sin inicializar o con valor null
		//var saludo;
		//var adios = null;
		
		// Cuidado con los arrays
		var numeros = new int[] {1,2,3,4,5};
		//var numeros2 = {1,2,3,4,5};  // ERROR
		
		// Colecciones
		var lista = new ArrayList<>();   		// lista de objetos
		var lista2 = new ArrayList<Integer>();  // lista de enteros
		var lista3 = new ArrayList<>(Arrays.asList(1,2,3,4,5)); // lista de enteros
		var lista4 = new ArrayList<Integer>(Arrays.asList(1,2,3,4,5)); // lista de enteros
		
		// Crear un bucle que muestre los numeros del 1 al 10
		for(var num=1; num <= 10; num++) {
			System.out.println(num);
		}
		
		// Crear un array de nombres y recorrerlo con inferencia de tipos
		var nombres = new String[] {"Juan", "Maria", "Pedro", "Luis", "Sara"};
		for (var item : nombres) {
			System.out.println(item);
		}

	}

}
