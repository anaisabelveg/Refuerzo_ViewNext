package com.viewnext;

import java.util.logging.Level;
import java.util.logging.Logger;

public class AppMain {

	public static void main(String[] args) {
		
		// El logger es el encargado de enviar los mensajes al log
		// Crear el logger
		Logger logger = Logger.getLogger(AppMain.class.getName());
		
		// Version 1
		logger.log(Level.INFO, "Mensaje de informacion");
		logger.log(Level.WARNING, "Mensaje de aviso");
		logger.log(Level.SEVERE, "Mensaje de error");
		
		// Version 2
		logger.log(Level.INFO, "Mensaje: {0}", "informacion .....");
		String msgWarning = "warning";
		logger.log(Level.WARNING, "Aviso: {0}", msgWarning);
		logger.log(Level.SEVERE, "Mensaje: {0}", "error");
		
		// Version 3
		logger.log(Level.INFO, "Mensaje: {0} {1}", new Object[] {"param1", "param2"});
		
		// Version 4
		logger.log(Level.SEVERE, "Mensaje de error", new Exception("Error"));

	}

}
