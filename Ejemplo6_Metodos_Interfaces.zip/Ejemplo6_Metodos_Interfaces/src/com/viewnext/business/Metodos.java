package com.viewnext.business;

public class Metodos implements ItfzMetodos{
	
	// Los metodos default se pueden sobrescribir
	
	@Override
	public void defecto() {
		System.out.println("Metodo default sobreescrito");
	}

}
