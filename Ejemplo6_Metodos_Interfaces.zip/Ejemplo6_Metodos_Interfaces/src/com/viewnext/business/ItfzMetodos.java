package com.viewnext.business;

public interface ItfzMetodos {
	
	// Novedades en Java 8 se incluyen:
	//  - metodos estaticos
	//  - metodos default
	
	public static void estatico() {
		System.out.println("Metodo estatico");
	}
	
	public default void defecto() {
		System.out.println("Metodo defecto");
	}
	
	// Novedad en Java 9:
	//  - metodos privados que se invocan a través del metodo default
	
	private String mayusculas(String texto) {
		return texto.toUpperCase();
	}
	
	private String minusculas(String texto) {
		return texto.toLowerCase();
	}
	
	public default String procesarTexto(String texto) {
		return "Mayusculas: " + mayusculas(texto) +
				" Minusculas: " + minusculas(texto);
	}

}
