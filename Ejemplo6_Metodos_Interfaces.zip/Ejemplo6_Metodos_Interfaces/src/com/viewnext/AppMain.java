package com.viewnext;

import com.viewnext.business.ItfzMetodos;
import com.viewnext.business.Metodos;

public class AppMain {

	public static void main(String[] args) {
		// Los metodos estaticos no necesitan instancia
		ItfzMetodos.estatico();
		
		// Los metodos default si necesitan una instancia
		ItfzMetodos metodos = new ItfzMetodos() {
		};
		metodos.defecto();
		
		Metodos metodos2 = new Metodos();
		metodos2.defecto();
		
		System.out.println(metodos.procesarTexto("Hola, que tal?"));

	}

}
