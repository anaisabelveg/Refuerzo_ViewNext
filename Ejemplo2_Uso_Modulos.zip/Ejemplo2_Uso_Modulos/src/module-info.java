module com.viewnext.ejemplo2 {
	
	// Para poder usar el modulo de otro proyecto:
	// 1.- agregar como dependencia del build path
	// 2.- importarlo como requires
	requires com.viewnext.ejemplo1;
}