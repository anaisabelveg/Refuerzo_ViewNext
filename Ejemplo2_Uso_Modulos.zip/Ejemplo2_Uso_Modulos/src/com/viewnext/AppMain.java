package com.viewnext;

import com.viewnext.models.Direccion;
import com.viewnext.models.Empleado;

public class AppMain {

	public static void main(String[] args) {
	
		Direccion dir1 = new Direccion("Mayor", 27, "Madrid");
		Empleado empleado = new Empleado(1, "Juan", 54_000, dir1);
		
		System.out.println(empleado);

	}

}
