module com.viewnext.ejemplo5 {
	
	// Necesito el modulo donde se declara la interface
	requires com.viewnext.ejemplo3;
	
	// Hay que indicar cual es la interface a utilizar
	uses com.viewnext.interfaz.ItfzSaludo;
}