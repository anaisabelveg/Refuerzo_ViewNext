package com.viewnext;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.Scanner;

public class AppMain {

	public static void main(String[] args) {
	
		Path path = Paths.get("mensajes.txt");
		try {
			Files.writeString(path, "", StandardOpenOption.CREATE);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		String mensaje = "";
		do {
			System.out.println("Escribe tu mensaje (FIN para terminar)");
			Scanner sc = new Scanner(System.in);
			mensaje = sc.nextLine();
			
			if (!mensaje.equals("FIN")) {
				try {
					Files.writeString(path, mensaje + "\n", StandardOpenOption.APPEND);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			
		} while (!mensaje.equals("FIN"));

	}

}
