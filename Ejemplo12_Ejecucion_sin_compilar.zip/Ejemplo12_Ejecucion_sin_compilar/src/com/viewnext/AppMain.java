package com.viewnext;

public class AppMain {

	public static void main(String[] args) {
		
		// java /Users/anaisabelvegascaceres/Desktop/Novedades_9_11_ViewNext/Ejemplo12_Ejecucion_sin_compilar/src/com/viewnext/AppMain.java
		System.out.println("Esto es una prueba para ejecutar codigo sin compilar");

		// OJO!! No funciona si hay dependencias con otras clases
		// p.e. Crear una instancia de Producto y luego mostrarla
	}

}
