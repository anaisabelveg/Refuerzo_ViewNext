package com.viewnext.interfaz;

public interface ItfzSaludo {
	
	String saludar();

}
