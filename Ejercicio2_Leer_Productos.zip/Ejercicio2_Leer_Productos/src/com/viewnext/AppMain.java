package com.viewnext;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import com.viewnext.models.Producto;

public class AppMain {

	public static void main(String[] args) {
		
		Path path = Paths.get("productos.txt");
		List<String> lineas = null;
		List<Producto> productos = new ArrayList<Producto>();
		
		try {
			lineas = Files.readAllLines(path);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		for(String linea : lineas) {
			// partir por -
			String[] datos = linea.split("-");
			
			// Eliminar los espacios en blanco
			for(var i=0; i<datos.length; i++) {
				datos[i] = datos[i].strip();
			}
			
			// parsear el id a entero y el precio a double
			int id = Integer.parseInt(datos[0]);
			String descripcion = datos[1];
			double precio = Double.parseDouble(datos[2]);
			
			// Crear la instancia de producto
			Producto producto = new Producto(id, descripcion, precio);
			
			// agregamos la instancia a la lista
			productos.add(producto);
		}
		
		// Mostrar la lista de productos
		productos.stream().forEach(System.out::println);

	}

}
