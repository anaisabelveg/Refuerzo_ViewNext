package com.viewnext;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class AppMain {

	public static void main(String[] args) {
		
		List<String> nombres = new ArrayList<String>();
		nombres.add("Juan");
		nombres.add("Maria");
		nombres.add("Pedro");
		nombres.add(null);
		nombres.remove(3);
		
		System.out.println(nombres);
		
		// Java 9 permite crear listas inmutables
		// como las tuplas en Python
		List<String> nombres2 = List.of("Juan", "Maria", "Pedro");
		
		// Las colecciones inmutables no soportan los valores nulos
		//List<String> nombres3 = List.of("Juan", "Maria", "Pedro", null);
		
		// Las colecciones inmutables no permite agregar o eliminar elementos
		// java.lang.UnsupportedOperationException
		// nombres2.remove(0);
		// nombres2.add("Otro");
		
		System.out.println(nombres2);
		
		// Las colecciones inmutables se utilizan para valores que no cambian
		List<String> dias = List.of("Lunes", "Martes", "Miercoles", "Jueves", "Viernes", "Sabado", "Domingo");
		
		// Set inmutables
		Set<String> estados = Set.of("Creada", "Asignada", "En curso", "Resuelta");
		
		// Mapa inmutable
		Map<Character, String> diasSemana = Map.of('L', "Lunes",'M', "Martes", 
				'X', "Miercoles", 'J', "Jueves",'V', "Viernes",'S', "Sabado",'D', "Domingo");
		
		System.out.println(diasSemana);
		
		// Solo quiero ver las letras del dia de la semana
		System.out.println(diasSemana.keySet());
		
		// Ver solo los dias de la semana
		System.out.println(diasSemana.values());
		
		// Mostrar cada elemento como un par key=value
		System.out.println(diasSemana.entrySet());
	}

}
