package com.viewnext.business;


// Para poder utilizar lambdas se necesita un interface funcional
// solo tiene un metodo abstracto

@FunctionalInterface
public interface ItfzCalculadora {

	double operacion(double n1, double n2);
}
